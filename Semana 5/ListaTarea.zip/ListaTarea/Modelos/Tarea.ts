export interface Tarea{
    id: number,
    text:string
}