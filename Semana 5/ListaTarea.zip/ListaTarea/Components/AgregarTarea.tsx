import { View, TextInput, Button, StyleSheet } from 'react-native';
import React, { useState } from 'react'
import { useContextTarea } from '../Context/ProviderTarea';

export default function AgregarTarea() {

    const [tarea,setTarea]=useState("")
    const {listaTarea, agregarTarea} = useContextTarea();


    const handleAddTask = () => {
        
        if (tarea.trim()) {
            agregarTarea(tarea);
            setTarea('');
        }
    };
  return (
    <View style={styles.container}>
    <TextInput
        style={styles.input}
        placeholder="Escribe una tarea"
        value={tarea}
        onChangeText={setTarea}
    />
    <Button title="Agregar Tarea" onPress={handleAddTask} />
</View>
  )
}

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 10,
    },
    input: {
        flex: 1,
        borderColor: '#ccc',
        borderWidth: 1,
        marginRight: 10,
        padding: 8,
        borderRadius: 5,
    },
});