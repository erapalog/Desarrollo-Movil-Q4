import { View, Text,FlatList,StyleSheet ,TouchableOpacity} from 'react-native'
import React from 'react'
import { useContextTarea } from '../Context/ProviderTarea';

export default function ListTarea() {

    const { listaTarea, deleteTask } = useContextTarea();

  return (
    <View>
          <FlatList
            data={listaTarea}
            keyExtractor={(item) => item.id.toString()}
            renderItem={({ item }) => (
                <View style={styles.taskItem}>
                    <Text style={styles.taskText}>{item.text}</Text>
                    <TouchableOpacity onPress={() => deleteTask(item.id)} style={styles.deleteButton}>
                        <Text style={styles.deleteText}>Eliminar</Text>
                    </TouchableOpacity>
                </View>
            )}
            ListEmptyComponent={<Text style={styles.emptyText}>No hay tareas</Text>}
        />
    </View>
  )
}

const styles = StyleSheet.create({
    taskItem: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        padding: 15,
        borderBottomWidth: 1,
        borderColor: '#ccc',
    },
    taskText: {
        fontSize: 16,
    },
    deleteButton: {
        backgroundColor: 'red',
        padding: 5,
        borderRadius: 5,
    },
    deleteText: {
        color: 'white',
        fontWeight: 'bold',
    },
    emptyText: {
        textAlign: 'center',
        marginTop: 20,
        fontSize: 16,
    },
});