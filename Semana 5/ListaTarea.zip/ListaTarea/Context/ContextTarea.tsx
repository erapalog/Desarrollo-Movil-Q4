import { createContext } from "react";
import {Tarea} from '../Modelos/Tarea'

export const contextTarea= createContext({
    
    listaTarea: [] as Tarea[],
    agregarTarea: (tarea:string) => {},
    deleteTask:(tareaId:number) =>{}
})