import { View, Text } from 'react-native'
import React, { ReactNode, useContext, useState } from 'react'
import {contextTarea} from '../Context/ContextTarea'
import { Tarea } from '../Modelos/Tarea'

interface Nodo{
    children: ReactNode
}

export default function ProviderTarea({children}:Nodo) {

    const [listaTarea, setListaTarea] = useState<Tarea[]>([])

    function agregarTarea(tarea:string){

        let body: Tarea={
            id:Math.floor(Math.random() * 1000) + 1,
            text:tarea
        }

        setListaTarea([...listaTarea,body])
    }

    //2
    const deleteTask = (tareaId:number) => {

        // 1 tarea 1---
        // 3 tarea 3---
        setListaTarea(listaTarea.filter(task => task.id !== tareaId));
    };
  return (
    <contextTarea.Provider value={{listaTarea,agregarTarea,deleteTask}}>
        {children}
    </contextTarea.Provider>
  )
}

export const useContextTarea = () =>{
    return useContext(contextTarea)
}